Project introduction
The game is very simple to play, you can move through our hero through the road to reach the other end of the road can pass.
Use steps
Step 1: run index.html
Step 2: through the keyboard keys to control the direction of the movement of our owners (but do not worry, I have to do a good job of control, your character will not move out of your scene)
Step 3: when the protagonist and the bugs encountered when the game starts, the hero will return to the starting point
PS: there are many things that need to be improved