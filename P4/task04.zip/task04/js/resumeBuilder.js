/*
This is empty on purpose! Your code to build the resume will go here.
 */
var bio = {
    "name": "Daji Wu",
    "role": "Web Teacher",
    "contacts": {
        "mobile": "0777-5957-5824",
        "email": "goutonga@qq.com",
        "github": "goutonga",
        "twitter": "@goutonga",
        "location": "Zhongguancun Street"
    },
    "welcomeMessage": "&nbsp;Thank you for visiting my resume.A position with your company would be both a learning experience" +
        " and a great opportunity." +
        "<br>&nbsp;&nbsp;I look forward to becoming part of your team. Thank you. ",
    "skills": ["HTML", "CSS", "JavaScript"],
    "biopic": "images/fry.jpg"
};

bio.display = function() {
    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    $("#header").prepend(formattedRole);
    $("#header").prepend(formattedName);

    for (var key in bio.contacts) {
        if (bio.contacts.hasOwnProperty(key)) {
            var formattedContact = HTMLcontactGeneric.replace("%contact%", key).replace("%data%", bio.contacts[key]);
            $("#topContacts").append(formattedContact);
            $("#footerContacts").append(formattedContact);
        }
    }

    var formattedMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    var formattedPic = HTMLbioPic.replace("%data%", bio.biopic);
    $("#header").append(formattedPic);
    $("#header").append(formattedMessage);

    $("#header").append(HTMLskillsStart);
    for (var i = 0; i < bio.skills.length; i++) {
        var formattedSkills = HTMLskills.replace("%data%", bio.skills[i]);
        $("#header").append(formattedSkills);
    }
};

var education = {
    "schools": [{
            "name": "Shandong University",
            "location": "Chaoyang Qu",
            "degree": "University",
            "majors": ['JAVA', 'HTML and CSS', 'PhotoShop', 'C++'],
            "dates": "2006-2010",
            "url": "www.sdu.edu.cn"
        },
        {
            "name": "JiNan University",
            "location": "Chaoyang Qu",
            "degree": "University",
            "majors": ['Math', 'HTML and CSS', 'PhotoShop'],
            "dates": "2003-2006",
            "url": "www.sdu.edu.cn"
        }
    ],
    "onlineCourses": [{
            "title": "Web",
            "school": "Udacity",
            "dates": "2016-2016",
            "url": "cn.udacity.com"
        },
        {
            "title": "Web",
            "school": "Mars",
            "dates": "2015-2015",
            "url": "edu.hxsd.com"
        }

    ]
};

education.display = function() {

    education.schools.forEach(function(school) {
        var formattedname = HTMLschoolName.replace("%data%", school.name);
        var formattedDegree = HTMLschoolDegree.replace("%data%", school.degree);
        var formattedDates = HTMLschoolDates.replace("%data%", school.dates);
        var formattedLocation = HTMLschoolLocation.replace("%data%", school.location);
        var formattedURL = HTMLschoolURL.replace("%data%", school.url);
        $("#education").append(HTMLschoolStart);
        $(".education-entry:last").append(formattedname + formattedDegree);
        $(".education-entry:last").append(formattedDates);
        $(".education-entry:last").append(formattedLocation);
        school.majors.forEach(function(major) {
            var formattedMajor = HTMLschoolMajor.replace("%data%", major);
            $(".education-entry:last").append(formattedMajor);
        });
        $(".education-entry:last").append(formattedURL);
    });

    $("#education").append(HTMLonlineClasses);
    education.onlineCourses.forEach(function(onlineCourse) {
        var formattedTitle = HTMLonlineTitle.replace("%data%", onlineCourse.title);
        var formattedSchool = HTMLonlineSchool.replace("%data%", onlineCourse.school);
        var formattedOnlineDates = HTMLonlineDates.replace("%data%", onlineCourse.dates);
        var formattedOnlineURL = HTMLonlineURL.replace("%data%", onlineCourse.url);
        $("#education").append(HTMLschoolStart);
        $(".education-entry:last").append(formattedTitle + formattedSchool);
        $(".education-entry:last").append(formattedOnlineDates);
        $(".education-entry:last").append(formattedOnlineURL);
    });
};

var work = {
    "jobs": [{
            "employer": "Mars School",
            "title": "Web Teacher",
            "location": "Haidian Qu",
            "dates": "2014-2016",
            "description": "Teach students to learn web knowledge"
        },
        {
            "employer": "WayCool School",
            "title": "Web Teacher",
            "location": "Haidian Qu",
            "dates": "2012-2014",
            "description": "Teach students to learn web knowledge"
        },
        {
            "employer": "DaNei",
            "title": "Web Teacher",
            "location": "Haidian Qu",
            "dates": "2010-2012",
            "description": "Teach students to learn web knowledge"
        }

    ]
};

work.display = function() {
    for (var i = 0; i < work.jobs.length; i++) {
        var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[i].employer);
        var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[i].title);
        var formattedEmployerTitle = formattedEmployer + formattedTitle;
        var formattedLocation = HTMLworkDates.replace("%data%", work.jobs[i].location);
        var formattedDates = HTMLworkLocation.replace("%data%", work.jobs[i].dates);
        var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[i].description);

        if (i % 2 === 0) {
            $("#work").append(HTMLworkStart);
            $(".work-entry.jingli:last").append(formattedEmployerTitle);
            $(".work-entry.jingli:last").append(formattedLocation);
            $(".work-entry.jingli:last").append(formattedDates);
            $(".work-entry.jingli:last").append(formattedDescription);
        } else {
            $("#work").append(HTMLworkStart.replace("jingli", "jingli2"));
            $(".work-entry.jingli2:last").append(formattedEmployerTitle);
            $(".work-entry.jingli2:last").append(formattedLocation);
            $(".work-entry.jingli2:last").append(formattedDates);
            $(".work-entry.jingli2:last").append(formattedDescription);
        }
    }
};


var projects = {
    "projects": [{
            "title": "Mars school website",
            "dates": "2016-2016",
            "description": "Software developed for enterprise management",
            "images": ['images/work_pic01_02.jpg', 'images/work_pic01_02.jpg']
        },
        {
            "title": "Customer management system",
            "dates": "2014-2015",
            "description": "Software developed for enterprise management",
            "images": ['images/work_pic01_02.jpg', 'images/work_pic01_02.jpg']
        },
        {
            "title": "Books Management System (BMS)",
            "dates": "2014-2014",
            "description": "Software developed for enterprise management",
            "images": ['images/work_pic01_02.jpg', 'images/work_pic01_02.jpg']
        }

    ]
};

projects.display = function() {
    projects.projects.forEach(function(project) {
        $("#projects").append(HTMLprojectStart);
        var formattedTitle = HTMLprojectTitle.replace("%data%", project.title);
        var formattedDates = HTMLprojectDates.replace("%data%", project.dates);
        var formattedDescription = HTMLprojectDescription.replace("%data%", project.description);
        $(".project-entry:last").append(formattedTitle);
        $(".project-entry:last").append(formattedDates);
        $(".project-entry:last").append(formattedDescription);
        var imagesArray = [];
        imagesArray = project.images;
        for (var i = 0; i < imagesArray.length; i++) {
            var formattedImage = HTMLprojectImage.replace("%data%", imagesArray[i]);
            $(".project-entry:last").append(formattedImage);
        }
    });
};

bio.display();
work.display();
projects.display();
education.display();

$("#mapDiv").append(googleMap);