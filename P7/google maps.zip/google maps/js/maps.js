/**
 * Created by sumin on 2016/12/5.
 */

var map;//Google maps
var infowindow; //Information box
var geocoder;//Geo coding
var placeMarkers = [];
var viewModel = null;
function initMap() {
    geocoder = new google.maps.Geocoder();
    var styles = [//Create a personalized map to change the color of the elements on the map
        {
            featureType: 'water',//Modify the color of water
            stylers: [
                { color: '#19a0d8' }
            ]
        },{
            featureType: 'administrative',//Modify the text frame color
            elementType: 'labels.text.stroke',//The element type is the outline or the element itself
            stylers: [
                { color: '#ffffff' },
                { weight: 6 }
            ]
        },{
            featureType: 'administrative',//Modify text color
            elementType: 'labels.text.fill',
            stylers: [
                { color: '#e85113' }
            ]
        },{
            featureType: 'road.highway',//Modify the color of the highway border
            elementType: 'geometry.stroke',
            stylers: [
                { color: '#efe9e4' },
                { lightness: -40 }
            ]
        },{
            featureType: 'transit.station',//Modify the color of the railway
            stylers: [
                { weight: 9 },
                { hue: '#e85113' }
            ]
        },{
            featureType: 'road.highway',
            elementType: 'labels.icon',
            stylers: [
                { visibility: 'off' }
            ]
        },{
            featureType: 'water',
            elementType: 'labels.text.stroke',
            stylers: [
                { lightness: 100 }
            ]
        },{
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [
                { lightness: -100 }
            ]
        },{
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [
                { visibility: 'on' },
                { color: '#f0e4d3' }
            ]
        },{
            featureType: 'road.highway',
            elementType: 'geometry.fill',
            stylers: [
                { color: '#efe9e4' },
                { lightness: -25 }
            ]
        }
    ];
    //39.904211
    //maps.js:139 116.40739499999995
    //var pyrmont = {lat: 40.7413549, lng: -73.9980244};
    //var pyrmont = {lat: 39.904211, lng: 116.40739499999995};//beijing
    var pyrmont = {lat: 31.230416, lng: 121.473701};
    map = new google.maps.Map(document.getElementById('map'), {//create Google map
        center: pyrmont,
        zoom: 15,
        mapTypeId:google.maps.MapTypeId.ROADMAP,//Specify map display type: satellite image, common road
        styles: styles,
        scrollwheel: true,//Allow the roller to slide
        mapTypeControl:true,//Display map control
        mapTypeControlOptions:{//Modify the position of the control map type
            style:google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
            position:google.maps.ControlPosition.TOP_RIGHT
        }
    });

    var search =document.getElementById('search');
    var autocomplete = new google.maps.places.Autocomplete(search);
    autocomplete.bindTo('bounds', map);
    var searchBox = new google.maps.places.SearchBox(search);
    // Bias the SearchBox results towards current map's viewport.
    /*search.onkeyup  = function(){
        //var placelist = viewModel.place;
        // if(viewModel.place != ''){ //判断文本框中是否输入内容
         //viewModel.placelist = [];
         codeAddress();
        // }
     };*/
    autocomplete.addListener('places_changed', function() {
        infowindow.close();
        marker.setVisible(false);
        var places = autocomplete.getPlaces();
        if (places.length == 0) {
            return;
        }
        createMarker(places);
    })
    //New information box
    infowindow = new google.maps.InfoWindow();

    //Returns a list of nearby locations based on user location
    var service = new google.maps.places.PlacesService(map);
    service.nearbySearch({//Launch site search near Places
        location: pyrmont,
        radius: 500,
        types: ['store']
    }, callback);

    // Listen for the event fired when the user selects a prediction and clicks "go" more details for that place.
    //document.getElementById('button').addEventListener('click', codeAddress);
    /*event init*/

}
function googleError() {
    alert("bad request");
}
function codeAddress() {
    //get input text
    var address = viewModel.query();
    //
    geocoder.geocode( { 'address': address}, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            /*console.log(results[0].geometry.location.lat());
            console.log(results[0].geometry.location.lng());*/
            map.setCenter(results[0].geometry.location);
            var marker = new google.maps.Marker({
                map: map,
                title: address,
                animation: google.maps.Animation.DROP,
                position: results[0].geometry.location
            });

            listen(address, marker);
        }
        if(results.length != 0)
        {
            var service = new google.maps.places.PlacesService(map);
            var repuest = {//Search for a radius of 500 within the store
                location: results[0].geometry.location,
                radius: 500,
                types: ['store']
            };
            service.nearbySearch(repuest, callback);
        }
    });
}

//This function firest when the user select "go" on the places search.
function textSearchPlaces() {//Address search
    var bounds = map.getBounds();
    addresslist.innerHTML = null;
    console.log('search');
    //createMarker(placeMarkers);
    var placesService = new google.maps.places.PlacesService(map);
    placesService.textSearch({
        query: viewModel.query,
        bounds: bounds
    }, function(results, status) {
        console.log(results.length);
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            callback(results);

        }
    });
}

//Create tag
function callback(results, status) {
    console.log(results.length);
    if (status === google.maps.places.PlacesServiceStatus.OK) {
        /*viewModel.places.removeAll();*/
        viewModel.places(results);
        for (var i = 0; i < results.length; i++) {
            createMarker(results[i]);
        }
    }
}

function createMarker(place) {
    //console.log(place);
    var marker;
    var bounds = new google.maps.LatLngBounds();
    var defaultIcon = makeMarkerIcon('0091ff');//Default color
    var lightedIcon = makeMarkerIcon('F1DA99');//Mouse move

    marker = new google.maps.Marker({//Create tag
        map: map,
        icon:defaultIcon,
        title:place.name,
        animation: google.maps.Animation.DROP,
        position: place.geometry.location,
    });
    place.marker = marker;

    viewModel.visiblePlaces.push(place);

    //var placesList = document.getElementById('addresslist');

        /*if(placesList == null){ //Determine whether the contents of the text box input
     placesList = "Chelsea, New York"
     }*/
    //placesList.innerHTML += '<li>' + place.name + '</li>';
    google.maps.event.addListener(marker, 'mouseover',function(){
        this.setIcon(lightedIcon);
    });
    google.maps.event.addListener(marker, 'mouseout',function(){
        this.setIcon(defaultIcon);
    });
    var placeName = place.name;
    listen(placeName,marker);
}

function makeMarkerIcon(markerColor) {//将 MarkerImage 对象转换为 Icon 类型
    var markerImage = new google.maps.MarkerImage(
        'http://chart.googleapis.com/chart?chst=d_map_spin&chld=1.15|0|'+ markerColor +
        '|40|_|%E2%80%A2',
        new google.maps.Size(21, 34),
        new google.maps.Point(0, 0),
        new google.maps.Point(10, 34),
        new google.maps.Size(21,34));
    return markerImage;
}

//wiki
function wiki(placeName){
    var $wikiElem = $('#wikipedialinks');
    var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + placeName + '&format=json&callback=wikiCallback';
    var widiRequestTimeout = setTimeout(function(){
        $wikiElem.html("failed to get widipedia resources");
    },8000);
    $.ajax({
        url:wikiUrl,
        dataType:"jsonp",
        //jsonp:"callback",
        success:function(response){
            //console.log(response);
            var articleList = response[1];
            if(articleList.length != 0)
                for(var i = 0; i< articleList.length; i++){
                    articleStr = articleList[i];
                    var url = 'http://en.wikipedia.org/wiki/' + articleStr;
                    setcontent(placeName,articleStr);
                    //$wikiElem.append('<li><a href="' + url +'">' + articleStr + '</a></li>');
                }
            else
                setcontent(placeName,"there is no data in widipedia resources!");
            clearTimeout(widiRequestTimeout);
        }
    });
}

function setcontent(placeName,aritcleStr){
    infowindow.setContent('<h3>'+ placeName +'<h3> <div>'+ aritcleStr +'</ div>');
}

function listen(placeName,marker){//Marks the listen event
    google.maps.event.addListener(marker, 'click', function() {//Monitor tag
        infowindow.setContent('<h3>'+ placeName + '</h3>'+ '<div id="wikipedialinks"></div> ');
        infowindow.open(map, this);
        wiki(placeName);
        if(marker.getAnimation() !== null){
            marker.setAnimation(null);
        }else{
            marker.setAnimation(google.maps.Animation.BOUNCE);
        }
        setTimeout(function(){
            marker.setAnimation(null);
        },1500);
    });
}
/*
//knockoutjs Search box text association
window.onload = function(){
     var ViewModel = function(){
        var self = this;
        self.place = ko.observable('');
        self.placelist = ko.observableArray([]);
console.log("hahah onload")
        self.codeAddress  = function () {
            var address = self.place();
            geocoder.geocode( { 'address': address}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    map.setCenter(results[0].geometry.location);
                    var marker = new google.maps.Marker({
                        map: map,
                        title:address,
                        animation: google.maps.Animation.DROP,
                        position: results[0].geometry.location
                    });
                    listen(address,marker);

                }
                if(results.length != 0)
                {
                    var service = new google.maps.places.PlacesService(map);
                    var repuest = {//检索方圆500之内的store
                        location: results[0].geometry.location,
                        radius: 500,
                        types: ['store']
                    };
                    service.nearbySearch(repuest, callback);
                }
            });
        }
    };
    viewModel = new ViewModel();
    ko.applyBindings(viewModel);
};*/

/*var place = function(data) {
    this.name = ko.observable(data.name);
    this.address = ko.observable(data.address);
    this.location = ko.observable(data.location);
    this.marker = ko.observable(data.marker);
}*/
var ViewModel = function() {
    var self = this;
    self.query = ko.observable('');
    self.places = ko.observableArray([]);
    //Filter locations for queries
    self.visiblePlaces = ko.observableArray([]);


    self.filterMarkers = function () {
       var filter = self.query();
        self.visiblePlaces.removeAll();
        self.places().forEach(function (place) {
            console.log(place.geometry.location.lat());
            console.log(place.geometry.location.lng());
            place.marker.setVisible(false);
            //Toponyms are also lowercase and filtered
            if (place.name.toLowerCase().indexOf(filter) !== -1) {
                self.visiblePlaces.push(place);
            }
        });
        //Search by location
        self.visiblePlaces().forEach(function (place) {
            place.marker.setVisible(true);
        });
      //codeAddress();
    };
    self.onclick = function (place) {
        console.log('click');
        console.log(place);
        google.maps.event.trigger(place.marker ,'click');
        console.log('click - after');
    };
    self.show = ko.observable(true);
    self.menuBarClick = function () {
        if(self.show())
        {
            $('.options_left').css('left','-240px');
        }
        else
        {
            $('.options_left').css('left','0px');
        }
        self.show(!self.show());
    };
};

viewModel = new ViewModel();

ko.applyBindings (viewModel);


