/**
 * Created by sumin on 2016/11/19.
 */
window.onload = function(){
    //knockoutjs搜索框文本关联
    var ViewModel = function(places){
        this.places = ko.observable(places);

        this.placesname = ko.computed(function(){
            return this.places();
        },this);
    };
    ko.applyBindings(new ViewModel());
}
