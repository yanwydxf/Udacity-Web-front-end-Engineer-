This is a Google Maps app-based map:
Key features include
1. Left-hand navigation area Click Hide / Show
2. You can filter the location according to the input
3. You can mark the specified location on the map
4. Tap the location on the map to display a prompt
how to use:
Open the index.html in the browser, the left navigation area on the action page can be completed according to the input filter search